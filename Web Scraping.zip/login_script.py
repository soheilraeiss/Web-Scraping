import requests
from urllib.parse import urlparse
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.firefox.service import Service as FirefoxService
from webdriver_manager.firefox import GeckoDriverManager
from selenium.common.exceptions import NoSuchElementException
import time
import sys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import os
from selenium.common.exceptions import WebDriverException

try:
    # First verify internet connection
    try:
        test_url = "https://www.google.com"
        # Enhanced connection check with multiple test sites
        test_sites = [
            "http://www.google.com",  # HTTP works better for initial checks
            "http://www.microsoft.com",
            "http://www.example.com"
        ]
        
        connection_ok = False
        for site in test_sites:
            try:
                requests.get(site, timeout=5)
                connection_ok = True
                break
            except requests.ConnectionError:
                continue
                
        if not connection_ok:
            print("\nTROUBLESHOOTING GUIDE:")
            print("1. Verify your network cables/WiFi connection")
            print("2. Try accessing these test sites manually:")
            for site in test_sites:
                print(f"   - {site}")
            print("3. If on university network, you may need to:")
            print("   a. Connect to VPN first")
            print("   b. Configure system proxy settings")
            sys.exit(1)
    except requests.ConnectionError:
        print(f"ERROR: No internet connection or can't reach {test_url}")
        print("Please check your network connection and try again")
        sys.exit(1)

    # Initialize Firefox driver with retry logic
    max_retries = 3
    for attempt in range(max_retries):
        try:
            options = webdriver.FirefoxOptions()
            options.add_argument("--start-maximized")
            
            # Add proxy configuration if environment variable exists
            if os.environ.get('HTTP_PROXY'):
                options.set_preference('network.proxy.type', 1)
                options.set_preference('network.proxy.http', os.environ.get('HTTP_PROXY').split(':')[0])
                options.set_preference('network.proxy.http_port', int(os.environ.get('HTTP_PROXY').split(':')[1]))
            
            driver = webdriver.Firefox(service=FirefoxService(GeckoDriverManager().install()), options=options)
            
            driver.set_page_load_timeout(30)
            try:
                print(f"Attempt {attempt + 1}: Connecting to website...")
                driver.get("https://ems.ut.ac.ir/")
                break
            except WebDriverException as e:
                if attempt == max_retries - 1:
                    print("Failed after maximum retries. Possible solutions:")
                    print("1. Check if website is accessible in your browser")
                    print("2. Configure proxy settings if on university network")
                    print("3. Try again later if server is down")
                    raise
                print(f"Connection failed, retrying in 5 seconds... ({attempt + 1}/{max_retries})")
                time.sleep(5)
                
        except Exception as e:
            if attempt == max_retries - 1:
                raise
            print(f"Attempt {attempt + 1} failed, retrying...")
            time.sleep(5)

    try:
        # Debugging: Print page source and take screenshot
        with open("c:\\Users\\seyed\\Desktop\\page_source.html", "w", encoding="utf-8") as f:
            f.write(driver.page_source)
        driver.save_screenshot("c:\\Users\\seyed\\Desktop\\initial_page.png")
        
        # Wait longer for initial page load
        print("Waiting for page to fully load...")
        time.sleep(10)  # Increased initial wait time
        
        # Enhanced element finding with multiple selector strategies
        username_selectors = [
            (By.NAME, "username"),
            (By.ID, "username"),
            (By.XPATH, "//input[contains(@class,'login')]"),
            (By.CSS_SELECTOR, "input[type='text']")
        ]
        
        password_selectors = [
            (By.NAME, "password"),
            (By.XPATH, "//input[@type='password']"),
            (By.CSS_SELECTOR, "input[type='password']")
        ]
        
        # Try different username field selectors
        for by, selector in username_selectors:
            try:
                username_field = WebDriverWait(driver, 5).until(
                    EC.presence_of_element_located((by, selector))
                )
                username_field.send_keys("raeisalsadati.so")
                break
            except:
                continue
        else:
            raise NoSuchElementException("Could not find username field with any selector")
            
        # Try different password field selectors
        for by, selector in password_selectors:
            try:
                password_field = WebDriverWait(driver, 5).until(
                    EC.presence_of_element_located((by, selector))
                )
                password_field.send_keys("KevinOconnell1@CANOPUS")
                break
            except:
                continue
        else:
            raise NoSuchElementException("Could not find password field with any selector")
            
        login_button = WebDriverWait(driver, 15).until(
            EC.element_to_be_clickable((By.XPATH, "//button[contains(.,'ورود') or contains(.,'Login') or contains(.,'Sign in')]"))
        )
        login_button.click()
        
        time.sleep(5)
        print("Login successful!")
        
        # After successful login, navigate to the specific subsection
        print("Navigating to subsection...")
        driver.get("https://ems2.ut.ac.ir/browser/fa/#/pages?fid=2200&ftype=1&seq=0&subfrm=&sguid=4f9cd4bd-74c0-4539-b970-a91bb68ea6f2&refPage=-1&TrmType=2#2200")
        time.sleep(5)  # Wait for subsection to load
        
        # Add print functionality for the subsection
        # After successful login, add print functionality
        print("Adding print functionality...")
        driver.execute_script("""
            // Create printable div
            var printableDiv = document.createElement('div');
            printableDiv.id = 'printableArea';
            printableDiv.innerHTML = document.documentElement.outerHTML;
            
            // Create print button
            var printBtn = document.createElement('button');
            printBtn.innerHTML = 'Print Page';
            printBtn.onclick = function() {
                var printWindow = window.open('', '_blank');
                printWindow.document.write('<html><head><title>Print</title>');
                printWindow.document.write('<style>');
                printWindow.document.write('body { direction: rtl; font-family: Tahoma; }');
                printWindow.document.write('@media print { @page { size: auto; margin: 0; } }');
                printWindow.document.write('</style></head><body>');
                printWindow.document.write(document.documentElement.outerHTML);
                printWindow.document.write('</body></html>');
                printWindow.document.close();
                printWindow.focus();
                setTimeout(function() {
                    printWindow.print();
                    printWindow.close();
                }, 500);
            };
            
            // Style the button
            printBtn.style.position = 'fixed';
            printBtn.style.bottom = '20px';
            printBtn.style.right = '20px';
            printBtn.style.zIndex = '9999';
            printBtn.style.padding = '10px 20px';
            printBtn.style.backgroundColor = '#4CAF50';
            printBtn.style.color = 'white';
            printBtn.style.border = 'none';
            printBtn.style.borderRadius = '4px';
            printBtn.style.cursor = 'pointer';
            
            document.body.appendChild(printBtn);
        """)
        
        # Wait for elements to be added
        time.sleep(2)
        
        print("Print button added to page. Click it to print the content.")
        document.body.appendChild(printableDiv);
            
            // Create print button
            var printBtn = document.createElement('input');
            printBtn.type = 'button';
            printBtn.value = 'Print This Section';
            printBtn.onclick = function() {
                var printContents = document.getElementById('printableArea').innerHTML;
                var originalContents = document.body.innerHTML;
                
                document.body.innerHTML = printContents;
                window.print();
                document.body.innerHTML = originalContents;
            };
            document.body.appendChild(printBtn);
            
            // Style the elements
            printableDiv.style.padding = '20px';
            printableDiv.style.border = '1px solid #ccc';
            printBtn.style.margin = '20px';
            printBtn.style.padding = '10px';
            printBtn.style.position = 'fixed';
            printBtn.style.top = '20px';
            printBtn.style.right = '20px';
            printBtn.style.zIndex = '9999';
            printBtn.style.backgroundColor = '#4CAF50';
            printBtn.style.color = 'white';
            printBtn.style.border = 'none';
            printBtn.style.borderRadius = '4px';
        """)
        
        # Wait for elements to be added
        time.sleep(2)
        
        # Click the print button automatically
        print_button = driver.find_element(By.XPATH, "//input[@value='Print This Section']")
        print_button.click()
        
        print("Print dialog should appear now...")
        
    except Exception as e:
        print(f"Error adding print functionality: {str(e)}")
        driver.save_screenshot("c:\\Users\\seyed\\Desktop\\print_error.png")
        
except Exception as e:
    print(f"Error occurred: {str(e)}")
    if 'driver' in locals():
        driver.save_screenshot("c:\\Users\\seyed\\Desktop\\connection_error.png")
    
finally:
    if 'driver' in locals():
        driver.quit()